'use client'
export default function Admin(){return(<div style={{padding:24}}><h1 style={{fontWeight:900,fontSize:28}}>NaijaStack OS • Admin</h1><p style={{marginTop:12}}>Real orders will show here after you run supabase.sql in Supabase and connect .env.local. Your tables are now fixed.</p></div>)}
