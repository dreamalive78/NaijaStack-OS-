export default function Home(){
 return (
  <div style={{maxWidth:720,margin:'40px auto',padding:24}}>
    <h1 style={{fontSize:42,fontWeight:900}}>NaijaStack OS</h1>
    <p style={{marginTop:8,color:'#666'}}>Nigeria's first USSD + WhatsApp Commerce OS</p>
    <div style={{marginTop:24,display:'grid',gap:12}}>
      <a href="/store/lagos-runner" style={{padding:16,background:'black',color:'white',borderRadius:12,textAlign:'center',fontWeight:700}}>🛒 View Demo Store</a>
      <a href="/admin" style={{padding:16,border:'1px solid #ddd',borderRadius:12,textAlign:'center',fontWeight:700}}>📊 Open Admin</a>
    </div>
    <div style={{marginTop:32,background:'#f6f6f6',padding:16,borderRadius:12,fontSize:13}}>
      <b>How to run:</b><br/>1. Run supabase.sql in Supabase<br/>2. Set .env.local<br/>3. npm install && npm run dev
    </div>
  </div>
 )
}
