'use client'
import { useState } from 'react'
export default function Page({params}:any){
 const [phone,setPhone]=useState(''); const [loading,setLoading]=useState(false); const [result,setResult]=useState<any>(null)
 async function buy(){
  setLoading(true)
  const res=await fetch('/api/checkout',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({slug:params.slug,phone,country:'NG',amount:15000})})
  setResult(await res.json()); setLoading(false)
 }
 return(<div style={{maxWidth:400,margin:'auto',padding:24}}><img src='https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600' style={{borderRadius:16,width:'100%'}}/><h1 style={{fontWeight:900,fontSize:24,marginTop:12}}>Lagos Street Runner</h1><p>₦15,000</p><input value={phone} onChange={e=>setPhone(e.target.value)} placeholder='080...' style={{width:'100%',padding:12,border:'1px solid #ccc',borderRadius:12,marginTop:12}}/><button onClick={buy} disabled={loading} style={{width:'100%',background:'black',color:'white',padding:12,borderRadius:12,marginTop:8}}>{loading?'Processing...':'Buy via USSD'}</button>{result&&<div style={{marginTop:16,background:'#f5f5f5',padding:12,borderRadius:12}}><p>USSD: {result.ussd}</p><a href={result.link} target='_blank' style={{color:'blue'}}>Pay Link</a></div>}</div>)
}
