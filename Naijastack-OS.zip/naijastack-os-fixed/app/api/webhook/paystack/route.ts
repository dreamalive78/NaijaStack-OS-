import { NextRequest } from "next/server"
import crypto from "crypto"
import { createClient } from "@supabase/supabase-js"
export async function POST(req:NextRequest){
 const body=await req.text()
 const sig=req.headers.get('x-paystack-signature')
 const secret=process.env.PAYSTACK_SECRET_KEY!
 const hash=crypto.createHmac('sha512',secret).update(body).digest('hex')
 if(hash!==sig) return Response.json({error:"Invalid signature"},{status:401})
 const event=JSON.parse(body)
 if(event.event==='charge.success'){
  try{
   const supabase=createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.SUPABASE_SERVICE_KEY!)
   await supabase.from('orders').update({status:'paid',paid_at:new Date().toISOString(),raw:event.data}).eq('reference',event.data.reference)
  }catch{}
 }
 return Response.json({received:true})
}
