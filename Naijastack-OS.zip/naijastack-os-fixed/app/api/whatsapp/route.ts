import { NextRequest } from "next/server"
import { collect } from "@/lib/payments/client"
export async function POST(req:NextRequest){
 const {message,phone,country}=await req.json()
 if(/pay|buy|order|how much/i.test(message)){
  const payment=await collect({phone,country:country||'NG',amount:15000,email:`${phone}@naijastack.os`})
  return Response.json({reply:`Oga! Na 15k for Lagos Runner. Pay here: ${payment.link} OR dial ${payment.ussd} for USSD. I go confirm am sharp.`,payment})
 }
 return Response.json({reply:`How far ${phone}! Na Musa be this from NaijaStack. You wan buy Lagos Runner? Just tell me "I wan pay" - I go send you link and USSD code.`})
}
