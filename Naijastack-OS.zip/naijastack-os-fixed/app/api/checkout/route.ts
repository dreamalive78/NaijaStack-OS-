import { NextRequest } from "next/server"
import { collect } from "@/lib/payments/client"
import { createClient } from "@supabase/supabase-js"
export async function POST(req:NextRequest){
 const {phone,country,amount,slug}=await req.json()
 if(!phone) return Response.json({error:"Phone required"},{status:400})
 const result=await collect({phone,country:country||'NG',amount:amount||15000,email:`${phone}@naijastack.os`,name:slug})
 try{
  const supabase=createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!)
  await supabase.from('orders').insert({product_slug:slug,phone,country,amount,status:'pending',provider:result.provider,reference:result.reference,raw:result})
 }catch{}
 return Response.json(result)
}
