export async function collect(input:{phone:string;country?:string;amount:number;email?:string;name?:string}){
 const reference=`NS_${Date.now()}_${Math.random().toString(36).slice(2,6)}`;
 return {status:'pending',provider:'mock',reference,ussd:`*901*${input.amount}#`,link:`https://paystack.com/pay/${reference}`,data:{authorization_url:`https://paystack.com/pay/${reference}`,reference,amount:input.amount}}
}
