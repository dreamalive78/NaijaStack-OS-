drop table if exists whatsapp_chats, orders, products, store_settings cascade;
create table products (id uuid primary key default gen_random_uuid(), slug text unique not null, name text not null, price int not null, image text, sizes text[] default '{42}', created_at timestamp default now());
create table orders (id uuid primary key default gen_random_uuid(), product_slug text, phone text not null, country text default 'NG', amount int not null, reference text unique, provider text default 'paystack', status text default 'pending', raw jsonb, paid_at timestamp, created_at timestamp default now());
create table whatsapp_chats (id uuid primary key default gen_random_uuid(), phone text, role text, message text, created_at timestamp default now());
create table store_settings (id uuid primary key default gen_random_uuid(), store_name text default 'NaijaStack OS Demo');
alter table products disable row level security; alter table orders disable row level security; alter table whatsapp_chats disable row level security; alter table store_settings disable row level security;
insert into products (slug, name, price, image, sizes) values ('lagos-runner','Lagos Street Runner',15000,'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600','{40,41,42,43}');
insert into store_settings (store_name) values ('NaijaStack OS Demo');
